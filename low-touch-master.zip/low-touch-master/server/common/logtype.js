const LogType = {
  Error: 'Error',
  Event: 'Event',
  Feedback: 'Feedback'
};

module.exports = LogType;
