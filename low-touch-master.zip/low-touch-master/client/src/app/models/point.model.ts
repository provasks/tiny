export class Point {
  x: number;
  y: number;
}
