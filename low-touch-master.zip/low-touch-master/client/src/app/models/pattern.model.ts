export class Pattern {
  R: number;
  r: number;
  d: number;
  color: string;
}
