export class Aggregates {
  aggregate: string;
  disks: number;
  raidType: string;
  thresholdExceedDate: string;
}
