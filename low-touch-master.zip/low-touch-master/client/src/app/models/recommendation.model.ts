export class Recommendation {
  key: string;
  value: string;
}
