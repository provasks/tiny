export class Part {
  partNo: string;
  quantity: number;
  description: string;
}
