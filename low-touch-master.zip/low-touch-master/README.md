    There are two seperate projects in this repository.

    1. Server: This project basically stores the data in a JSON file and expose those data to the client through different API (Application Programming Interface).
    To see the detail please refer low-touch/server/README.md

    2. Client: This project is Basically contain different UI which communicate with the SERVER Project to display the data
    To see the detail please refer low-touch/client/README.md
